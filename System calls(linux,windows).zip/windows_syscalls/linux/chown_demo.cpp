#include <iostream>
#include <unistd.h>
using namespace std;

int main() {
    int result = chown("input.txt", 1000, 1000);

    if(result == 0)
        cout << "Owner changed successfully\n";
    else
        cout << "Error (Run with sudo)\n";

    return 0;
}
